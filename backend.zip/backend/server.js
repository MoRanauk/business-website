// backend/server.js
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path'); // Import the 'path' module

const app = express();
const PORT = process.env.PORT || 5000; // Use process.env.PORT for hosting environments

// Middleware
app.use(bodyParser.json()); // To parse JSON request bodies
app.use(cors()); // Enable CORS for all origins (for development)

// Serve static files from the React build directory
// This assumes your 'build' folder has been copied directly into your 'backend' folder.
// REMOVED: The redundant app.use(express.static(path.join(__dirname, '../frontend/build')));
app.use(express.static(path.join(__dirname, 'build'))); // THIS IS THE CORRECT LINE

// Basic API route for testing
app.get('/api', (req, res) => { // Changed to '/api' to avoid conflict with '/' for static files
    res.send('Welcome to the Business Website Backend API!');
});

// User routes (will be defined in a separate file later for modularity)
app.post('/api/register', (req, res) => {
    console.log('Registration request received:', req.body);
    // Placeholder for user registration logic
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        return res.status(400).json({ message: 'Please enter all fields' });
    }
    res.status(200).json({ message: 'User registered successfully (placeholder)', user: { username, email } });
});

app.post('/api/login', (req, res) => {
    console.log('Login request received:', req.body);
    // Placeholder for user login logic
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).json({ message: 'Please enter all fields' });
    }
    // In a real app, you would verify credentials against a database
    if (email === 'test@example.com' && password === 'password123') {
        res.status(200).json({ message: 'Login successful (placeholder)', token: 'mock-jwt-token' });
    } else {
        res.status(401).json({ message: 'Invalid credentials (placeholder)' });
    }
});

// Protected admin route (requires authentication later)
app.get('/api/admin-dashboard', (req, res) => {
    // In a real application, you would check for authentication token here
    res.status(200).json({ message: 'Welcome to the Admin Dashboard!' });
});

// Catch-all to serve React app for any other request
// This needs to be placed after all your API routes.
// REMOVED: The redundant app.get('*', ...);
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, 'build', 'index.html')); // THIS IS THE CORRECT LINE
});

// Start the server
app.listen(PORT, () => {
    console.log(Backend server running on port ${PORT}); // Corrected: Used backticks for template literal
});
